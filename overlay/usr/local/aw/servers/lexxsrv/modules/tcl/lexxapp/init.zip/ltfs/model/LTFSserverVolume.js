Ext.define("P5Admin.model.LTFSserverVolume", {
    extend: "Ext.data.TreeModel",
    idProperty: "elementurl",
    schema: {
        namespace: "P5Admin.model"
    },

    fields: [{
        name: 'name',
        type: 'string'
    },{
        name: 'path',
        type: 'string'
    },{
        name: 'elementurl',
        type: 'string'
    },{
        name: 'duration',
        type: 'string'
    }],
    proxy:{
        type:'ajax',
        url: document.dataForm.ltfs_config.value,
        actionMethods:{
             read:'GET'
        },
        extraParams: {
            caller: 'ajaxGetLTFSserverVolume',
            hostname: 'localhost'
        },
        reader:{
            type:'json'
        }
    }
});
