Ext.define('P5U.model.Clients', {
	extend: 'Ext.data.Model',
		fields: [
			{name: 'name',  type: 'string', defaultValue: ''},
			{name: 'elementurl',  type: 'string', defaultValue: ''},
			{name: 'text', type: 'string', defaultValue: '' }
		]
});
