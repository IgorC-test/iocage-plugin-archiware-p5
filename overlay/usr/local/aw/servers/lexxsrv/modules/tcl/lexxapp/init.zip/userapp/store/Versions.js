Ext.define('P5U.store.Versions', {
    extend: 'Ext.data.Store',
    model: 'P5U.model.Versions',
    autoLoad: false,
    
    proxy: {
		type: 'ajax',
		url: P5U.globals.serverpage,
		actionMethods: 'POST',
		extraParams: {
			caller: 'ajaxGetVersions'
		},
        reader: {
			type: 'xml',
			record: 'version'
        },
		afterRequest: testResponse
    },
    sorters: { property: 'btime', direction : 'DESC' }
});