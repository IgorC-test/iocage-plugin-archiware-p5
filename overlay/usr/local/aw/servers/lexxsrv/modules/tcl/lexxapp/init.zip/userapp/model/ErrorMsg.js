Ext.define('P5U.model.ErrorMsg', {
	extend: 'Ext.data.Model',
	fields: ['id', 'msg']
});
