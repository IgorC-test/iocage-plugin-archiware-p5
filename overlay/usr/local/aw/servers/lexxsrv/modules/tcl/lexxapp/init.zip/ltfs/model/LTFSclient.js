Ext.define("P5Admin.model.LTFSclient", {
    extend: "Ext.data.Model",
    idProperty: "elementurl",
    schema: {
        namespace: "P5Admin.model"
    },

    fields: [{
        name: 'name',
        type: 'string'
    },{
        name: 'elementurl',
        type: 'string'
    },{
        name: 'text',
        type: 'string'
    }],
    proxy:{
        type:'ajax',
        url: document.dataForm.ltfs_config.value,
        actionMethods:{
             read:'GET'
        },
        extraParams: {
            caller: 'ajaxGetLTFSclient'
        },
        reader:{
            type: 'xml',
            root: 'clients',
            record: 'client'
        }
    }
});
