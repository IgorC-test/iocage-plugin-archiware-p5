//#############################################################################

//MainPanel.js

//JavaScript Client Library

//See the file "license.txt" for information on usage and
//redistribution of this file, and for a DISCLAIMER OF ALL WARRANTIES.


//#############################################################################

Ext.define("P5Admin.view.MainPanel", {
    extend: 'Ext.panel.Panel',
    alias: "widget.mainpanel",

    controller: "mainpanel",
    viewModel: {
        type: "mainpanel"
    },

    title: $$('Read/Write LTFS Tape'),
    
    layout: 'border',
    padding: '0',
    border: false,
    items: [{
        region: 'west',
        xtype: 'ltfsgrid',
        border: false,
        width: 520
    }, {
        region: 'center',
        xtype: 'ltfsoperation',
        border: false,
        flex: 1
    }],

});
