Ext.define('P5U.model.FolderContent', {
	extend: 'Ext.data.Model',
		fields: [
			{name: 'id',  type: 'string', defaultValue: ''},
			{name: 'name', type: 'string', defaultValue: '' },
			{name: 'path', type: 'string', defaultValue: '' }
		]
});
