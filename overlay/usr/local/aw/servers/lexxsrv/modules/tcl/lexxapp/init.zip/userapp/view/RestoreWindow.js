// Restore Window ----------------------------
Ext.define('P5U.view.RestoreWindow', {
    extend: 'Ext.window.Window',
    alias: 'widget.restoreWindow',

	width:450,
	height:220,
	layout:'fit',
	resizable: true,
	border: false,
	constrain: true,
	closeAction: 'hide'
});
// Form ----------------------------
Ext.define('P5U.view.restoreForm', {
	extend: 'Ext.form.Panel',
	alias : 'widget.restoreForm',

	frame: true,
	waitMsgTarget:true,
	bodyStyle: 'padding: 5px',
    items:[{
        xtype: 'fieldcontainer',
		fieldLabel: $$('Restore To'),
		labelAlign: 'top',
		style: {
    		marginTop: '5px',
    		marginLeft: '10px',
    		marginBottom: '0px'
    	}
	},{
        xtype: 'displayfield',
        name: 'displayPath',
        width: 400,
        fieldStyle: 'font-size:11px;font-style: italic;',
        style: { marginLeft: "10px" }
    },{
        xtype: 'button',
        name: 'browsePath',
        //disabled: true,
        text: $$('Change')+' ...',
        action: 'filePickerPath',
        style: { marginLeft: "15px" }
    },{
        margin: '10 20 20 12',
        xtype: 'component',
        html: $$("Note: If file already exists, recovered file name ends in '_R'.")

    }],
	buttons: [{
        text: $$('Cancel'),
        handler: function() {
            this.up().up().up().close();
        }
    },{
		text: $$('Start'),
		action: 'restoreStart',
		formBind: true
	}]
});
