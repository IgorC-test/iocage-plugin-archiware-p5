//#############################################################################

//config.js

//JavaScript Client Library

//See the file "license.txt" for information on usage and
//redistribution of this file, and for a DISCLAIMER OF ALL WARRANTIES.


//#############################################################################

console.log('Hallo');


Ext.define("P5Admin.Application", {
    extend: "Ext.app.Application",
    name: "P5Admin",
    launch: function() {
        var window_tree = Ext.create('P5Admin.view.MainPanel', {
            layout: 'border',
            padding: '0',
            border: false
        });       

	    Ext.getCmp('centercenter').add(window_tree);

        console.log(Ext.Loader.getPath('P5Admin'));
        console.log(Ext.Loader.getPath('P5Admin.view.MainPanelViewModel'));
        //Demo.main = Ext.ComponentQuery.query("mainpanel")[0];
        //Demo.vm = Demo.main.getViewModel()
    }
});
Ext.scopeCss = true;
Ext.application({
    name: "P5Admin",
    extend: "P5Admin.Application",
	appFolder: '/lexxapp/ltfs',
    //models: ['LTFSlocation'],
    //views: ['MainPanel'],
	requires: [ 
	    'P5Admin.view.LTFSGrid',
	    'P5Admin.view.LTFSOperation',
	    'P5Admin.view.MainPanelViewModel',
	    'P5Admin.view.MainPanelController',
	    'P5Admin.view.ReadWriteStatus',
	    'P5Admin.view.LTFSFilePicker',
	    'P5Admin.view.LTFSlabel'
	],
});

blockBrowser(false);
