Ext.define("P5idx.model.IdxServerVolume", {
    extend: "Ext.data.TreeModel",
    idProperty: "elementurl",
    schema: {
        namespace: "P5idx.model"
    },

    fields: [{
        name: 'name',
        type: 'string'
    },{
        name: 'path',
        type: 'string'
    },{
        name: 'elementurl',
        type: 'string'
    },{
        name: 'duration',
        type: 'string'
    }],
    proxy:{
        type:'ajax',
        url: P5idx.globals.serverpage,
        actionMethods:{
             read:'GET'
        },
        extraParams: {
            caller: 'ajaxGetServerVolume',
            hostname: 'localhost'
        },
        reader:{
            type:'json'
        },
		afterRequest: testResponse
    }
});
