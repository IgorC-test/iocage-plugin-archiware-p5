Ext.define('P5Admin.view.ReadWriteStatus', {
    extend: 'Ext.window.Window',
    alias: 'widget.readwritstatus',

    controller: "mainpanel",

	width:400,
	height:160,
	layout:'fit',
	resizable: false,
	border: false,
	constrain: true,
	closeAction: 'hide',
	modal: true,

	items: {
		xtype: 'form',
        itemId: 'readwritstatusform_id',
		frame: true,
		items: [{
        	xtype: 'hiddenfield',
        	name: 'jobname',
			value: ''
		},{
        	xtype: 'component',
        	margin: '5 20 0 20',
			html: "<span id='readWriteProcess'><span>"
		},{
			xtype: 'fieldcontainer',
			layout: 'hbox',
			items: [{
				xtype: 'readWriteShortMsg',
				cls: 'configpogress_bar',
			    width: 280,
			    height: 18,
        		margin: '7 0 0 20'
			},{
				xtype: 'button',
				action: 'cancelReadWrite',
				text: $$('Cancel'),
        		margin: '4 20 0 5'
			}]
		},{
        	xtype: 'readWriteLongMsg',
        	margin: '0 20 0 20',
			width: 350,
			cls: 'readWriteLongMsg',
			html: "<span id='readWriteProcessLong'><span>"
        }]
    },
	buttons: [{
        text: $$('Job Monitor'),
        handler: function() {
            jobMonitor();
            this.up().up().close();
        },
        bind:{
            hidden:'{enableMonitor}',
        }
    },{
        text: $$('Close'),
        handler: function() {
            this.up().up().close();
        }
	}]
});

Ext.define('P5Admin.view.ReadWriteShortMsg', {
    extend: 'Ext.ProgressBar',
    alias: 'widget.readWriteShortMsg',

    textEl: 'readWriteProcess'
});

Ext.define('P5Admin.view.ReadWriteLongMsg', {
    extend: 'Ext.Component',
    alias: 'widget.readWriteLongMsg',

    textEl: 'readWriteProcessLong'
});
