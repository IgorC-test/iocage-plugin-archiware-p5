// Restore Status Window ----------------------------
Ext.define('P5U.view.RestoreStatus', {
    extend: 'Ext.window.Window',
    alias: 'widget.restoreStatus_x',

	width:400,
	height:160,
	layout:'fit',
	resizable: false,
	border: false,
	constrain: true,
	closeAction: 'hide',
	items: {
		xtype: 'form',
		frame: true,
		items: [{
        	xtype: 'component',
        	margin: '5 20 0 20',
			//html: $$('Restore in process'),
			html: "<span id='restoreProcess'><span>"
		},{
			xtype: 'fieldcontainer',
			layout: 'hbox',
			items: [{
				xtype: 'restoreShortMsg_x',
				cls: 'pogress_bar',
			    width: 280,
			    height: 18,
        		margin: '7 0 0 20'
			},{
				xtype: 'button',
				action: 'cancelRestore',
				text: $$('Cancel'),
        		margin: '4 20 0 5'
			}]
		},{
        	xtype: 'restoreLongMsg_x',
        	margin: '0 20 0 20',
			width: 350,
			cls: 'restoreLongMsg',
			html: "<span id='restoreProcessLong'><span>"
        }]
    },
	buttons: [{
        text: $$('Close'),
        handler: function() {
            this.up().up().close();
        }
	}]
});

Ext.define('P5U.view.restoreShortMsg', {
    extend: 'Ext.ProgressBar',
    alias: 'widget.restoreShortMsg_x',

    textEl: 'restoreProcess'
});

Ext.define('P5U.view.restoreLongMsg', {
    extend: 'Ext.Component',
    alias: 'widget.restoreLongMsg_x',

    textEl: 'restoreProcessLong'
});
