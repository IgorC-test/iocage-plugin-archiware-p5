Ext.define("P5idx.model.IdxClient", {
    extend: "Ext.data.Model",
    idProperty: "elementurl",
    schema: {
        namespace: "P5idx.model"
    },

    fields: [{
        name: 'name',
        type: 'string'
    },{
        name: 'elementurl',
        type: 'string'
    },{
        name: 'text',
        type: 'string'
    }],
    proxy:{
        type:'ajax',
        url: P5idx.globals.serverpage,
        actionMethods:{
             read:'GET'
        },
        extraParams: {
            caller: 'ajaxGetClient'
        },
        reader:{
            type: 'xml',
            root: 'clients',
            record: 'client'
        },
		afterRequest: testResponse
    }
});
