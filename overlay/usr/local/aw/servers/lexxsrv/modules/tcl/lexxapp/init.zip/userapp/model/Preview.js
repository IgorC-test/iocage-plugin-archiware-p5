Ext.define('P5U.model.Preview', {
    extend: 'Ext.data.Model',
	fields: [
	         {name: 'name',  type: 'string', defaultValue: ''},
	         {name: 'type',  type: 'string', defaultValue: ''},
	         {name: 'pvsize',  type: 'int', defaultValue: 160},
	         {name: 'xsize',  type: 'int', defaultValue: 160},
	         {name: 'ysize', type: 'int', defaultValue: 160},
	         {name: 'clippath', type: 'string', defaultValue: ''},
	         {name: 'container', type: 'string', defaultValue: ''},
	         {name: 'media', type: 'string', defaultValue: ''}
	         ]
});