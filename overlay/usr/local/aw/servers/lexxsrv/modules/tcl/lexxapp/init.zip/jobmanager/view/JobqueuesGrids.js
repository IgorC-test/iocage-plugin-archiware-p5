Ext.define("P5Jobmanager.view.JobQueuesGrids", {
    extend: 'Ext.panel.Panel',
    alias: "widget.jobqueuesgrids",
    
    layout: {
        type: 'hbox',
        pack: 'start',
        align: 'stretch'
    },

    reference: 'jobqueuesgrids_ref',

    border: false,
        
    items: [{
        title: $$('Time Queue'),
        xtype: 'scheduledjobqueuegrid',
        flex: 1,
        bind: { hidden: '{!scheduledJobQueues_ref.checked}' }
    },{
        title: $$('Ordered Queue(s)'),
        xtype: 'orderedjobqueuegrid',
        flex: 1
    }]
});

Ext.define("P5Jobmanager.view.ScheduledJobQueueGrid", {
    extend: 'Ext.grid.Panel',
    alias: "widget.scheduledjobqueuegrid",

    bind:{
        store: '{scheduledqueuestore}'
    },
    reference: 'scheduledjobqueuegrid_ref',
    itemId: 'scheduledjobqueuegrid_id',

    columns: [
        { text: $$('Plan Name/Operation'), dataIndex: 'title', width: 200 },
        { text: $$('Client'), dataIndex: 'client', width: 80 },
        { text: $$('Level'), dataIndex: 'level', width: 80 },
        { text: $$('Start Time'), dataIndex: 'start', width: 80 },
        { text: $$('Job'), dataIndex: 'name', flex: 1 }
    ],
    dockedItems: [{
        margin: '0 0 0 0',
        xtype: 'toolbar',
        dock: 'bottom',
        layout: { pack: 'start' },
        items: [{
            xtype: 'button', scale: 'small', iconCls: 'fa fa-refresh awesomeIconS', handler:'onMonitorgridReload', text: $$('Reload')
        }]
    }]
});
Ext.define("P5Jobmanager.view.OrderedJobQueueGrid", {
    extend: 'Ext.grid.Panel',
    alias: "widget.orderedjobqueuegrid",

    bind:{
        store: '{orderedqueuestore}',
        hidden: '{isOrderedJobsQueuesChecked}'
    },
    reference: 'orderedjobqueuegrid_ref',
    itemId: 'orderedjobqueuegrid_id',

    columns: [
        { text: $$('Plan Name/Operation'), dataIndex: 'title', width: 200 },
        { text: $$('Client'), dataIndex: 'client', width: 80 },
        { text: $$('Level'), dataIndex: 'level', width: 80 },
        { text: $$('Start Time'), dataIndex: 'start', width: 80 },
        { text: $$('Job'), dataIndex: 'name', flex: 1 }
    ],
    dockedItems: [{
        margin: '0 0 0 0',
        xtype: 'toolbar',
        dock: 'bottom',
        layout: { pack: 'start' },
        items: [{
            xtype: 'button', scale: 'small', iconCls: 'fa fa-refresh awesomeIconS', handler:'onMonitorgridReload', text: $$('Reload')
        }]
    }]
});
