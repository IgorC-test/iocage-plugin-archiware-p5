Ext.define("P5Jobmanager.model.OrderedQueues", {
    extend: "Ext.data.Model",
    idProperty: "value",
    schema: {
        namespace: "P5Jobmanager.model"
    },
    fields: [{
        name: 'value',
        type: 'string'
    },{
        name: 'fieldLabel',
        type: 'string'
    }],
    proxy:{
        type:'ajax',
        url: P5Jobmanager.globals.serverpage,
        actionMethods:{
             read:'GET'
        },
        extraParams: {
            tdp: 'orderedqueues',
            caller: 'ajaxGetOrderedQueues'
        },
        reader:{
            type:'json',
            rootProperty:'data'
        }
    }
});