Ext.define('P5U.model.Metadata', {
    extend: 'Ext.data.Model'
});

Ext.define('DisplayDatefield', {
	extend: 'Ext.form.field.Display',
	alias: ['widget.displaydatefield'],

	rawToValue: function(rawValue) {
		return renderDate(rawValue);
	},
	valueToRaw: function(value) {
		return renderDate(value);
	}
});

Ext.define('DisplaySizefield', {
	extend: 'Ext.form.field.Display',
	alias: ['widget.displaysizefield'],

	rawToValue: function(rawValue) {
		return calcSizeIdx(rawValue);
	},
	valueToRaw: function(value) {
		return calcSizeIdx(value);
	}
});
