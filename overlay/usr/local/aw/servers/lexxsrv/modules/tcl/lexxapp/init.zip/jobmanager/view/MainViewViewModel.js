Ext.define('P5Jobmanager.view.MainViewViewModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.mainview',

    requires:[
        'P5Jobmanager.model.JobmonitorListing',
        'P5Jobmanager.model.JoblogListing',
        'P5Jobmanager.model.UserQueues'
    ],

    data:{
        servertime: ''
    },

    stores: {
        userqueuesstore: {
            model: 'P5Jobmanager.model.UserQueues',
            autoLoad: false,
            listeners: {
                load: 'onUserqueueStoreLoad'
            }
        },
        jobmonitorstore: {
            model: 'P5Jobmanager.model.JobmonitorListing',
            autoLoad: false,
            listeners: {
                load: 'onJobmonitorStoreLoad'
            }
        },
        runningjobsstore: {
            source: '{jobmonitorstore}',
            sorters: [{
                property: 'start',
                direction: 'ASC'
            }],
            filters: {
                property: 'status', operator: '!=', value: 'scheduled'
            }
        },
        archivejobsstore: {
            source: '{runningjobsstore}',
            sorters: [{
                property: 'start',
                direction: 'ASC'
            }],
            filters: {
                //property: 'jtype', value: /(backupjob)|(archivejob)/
                property: 'jtype', value: "archivejob"
            }
        },
        backupjobsstore: {
            source: '{runningjobsstore}',
            sorters: [{
                property: 'start',
                direction: 'ASC'
            }],
            filters: {
                property: 'jtype', value: "backupjob"
            }
        },
        restorejobsstore: {
            source: '{runningjobsstore}',
            sorters: [{
                property: 'start',
                direction: 'ASC'
            }],
            filters: {
                property: 'jtype', value: 'restorejob'
            }
        },
        syncjobsstore: {
            source: '{runningjobsstore}',
            sorters: [{
                property: 'start',
                direction: 'ASC'
            }],
            filters: {
                property: 'jtype', value: 'syncjob'
            }
        },
        othersjobsstore: {
            source: '{runningjobsstore}',
            sorters: [{
                property: 'start',
                direction: 'ASC'
            }],
            filters: {
                property: 'jtype', value: 'otherjob'
            }
        },
        scheduledqueuestore: {
            source: '{jobmonitorstore}',
            filters: [{
                property: 'status', value: 'scheduled'
            },{
                property: 'queue', value: 'time'
            }]
        },
        joblogstore: {
            model: 'P5Jobmanager.model.JoblogListing',
            autoLoad: false,
            remoteSort: true,
            pageSize: 10,
            sorters: [{
                property: 'timeCompleted',
                direction: 'DESC'
            }],
            listeners: {
                load: 'onJoblogStoreLoad',
            }
        },
        archivelogssstore: {
            source: '{joblogstore}',
            sorters: [{
                property: 'start',
                direction: 'ASC'
            }],
            filters: {
                //property: 'jtype', value: /(backupjob)|(archivejob)/
                property: 'jtype', value: "archivejob"
            }
        },
        backuplogsstore: {
            source: '{joblogstore}',
            sorters: [{
                property: 'start',
                direction: 'ASC'
            }],
            filters: {
                property: 'jtype', value: "backupjob"
            }
        },
        restorelogsstore: {
            source: '{joblogstore}',
            sorters: [{
                property: 'start',
                direction: 'ASC'
            }],
            filters: {
                property: 'jtype', value: 'restorejob'
            }
        },
        synclogsstore: {
            source: '{joblogstore}',
            sorters: [{
                property: 'start',
                direction: 'ASC'
            }],
            filters: {
                property: 'jtype', value: 'syncjob'
            }
        },
        otherslogsstore: {
            source: '{joblogstore}',
            sorters: [{
                property: 'start',
                direction: 'ASC'
            }],
            filters: {
                property: 'jtype', value: 'otherjob'
            }
        }
    },
    formulas: {
        isAjobMonitorChecked: {
            single: true,
            get: function(get) {
                return ( !get('anyJobMonitor_ref.checked') && !get('archiveJobMonitor_ref.checked') && !get('backupJobMonitor_ref.checked') && !get('restoreJobMonitor_ref.checked') && !get('syncJobMonitor_ref.checked') && !get('othersJobMonitor_ref.checked') ) ? true : false
            }
        },
        isAnyJobMonitor: {
            get: function(get) {
                return ( !get('anyJobMonitor_ref.checked') ) ? false : true
            }
        },
        isArchiveJobMonitor: {
            get: function(get) {
                return ( !get('anyJobMonitor_ref.checked') && get('archiveJobMonitor_ref.checked') ) ? false : true
            }
        },
        isBackupJobMonitor: {
            get: function(get) {
                return ( !get('anyJobMonitor_ref.checked') && get('backupJobMonitor_ref.checked') ) ? false : true
            }
        },
        isRestoreJobMonitor: {
            get: function(get) {
                return ( !get('anyJobMonitor_ref.checked') && get('restoreJobMonitor_ref.checked') ) ? false : true
            }
        },
        isSyncJobMonitor: {
            get: function(get) {
                return ( !get('anyJobMonitor_ref.checked') && get('syncJobMonitor_ref.checked') ) ? false : true
            }
        },
        isOthersJobMonitor: {
            get: function(get) {
                return ( !get('anyJobMonitor_ref.checked') && get('othersJobMonitor_ref.checked') ) ? false : true
            }
        },
        hasOrderedJobsQueueRecords: {
            bind: {
                 bindTo:'{userqueuesstore}',
                 deep:true
            },
            get: function(store) {
                return ( store.getCount() > 0 ) ? true : false
            }
        },
        isOrderedJobsQueuesChecked: {
            get: function(get) {
                return ( get('hasOrderedJobsQueueRecords') && get('userqueue_chkbx_ref.checked') ) ? false : true
            }
        }
    }
});
