Ext.define('P5U.store.FolderContent', {
	extend: 'Ext.data.TreeStore',
    model: 'P5U.model.FolderContent',
    autoLoad: false,
    
    proxy: {
		type: 'ajax',
		url: P5U.globals.serverpage,
		timeout: 10000,
		actionMethods: 'POST',
		extraParams: {
			caller: 'ajaxGetFolderContent'
		},
        reader: {
			type: 'xml',
			rootProperty: 'nodes',
			record: 'node'
        },
		afterRequest: testResponse
    },
	sorters: [{
		property: 'leaf',
		direction: 'ASC'
	},{
		property: 'name',
		direction: 'ASC'
	}]
});