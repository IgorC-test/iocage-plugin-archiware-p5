Ext.define("P5Admin.model.LTFSfolderContent", {
    extend: "Ext.data.TreeModel",
    idProperty: "id",
    schema: {
        namespace: "P5Admin.model"
    },

    fields: [{
        name: 'id',
        type: 'string'
    },{
        name: 'path',
        type: 'string'
    },{
        name: 'name',
        type: 'string'
    }],
    proxy:{
        type:'ajax',
        url: document.dataForm.ltfs_config.value,
        timeout: 600000,
        actionMethods:{
             read:'GET'
        },
        extraParams: {
            caller: 'ajaxGetLTFSfolderContent'
        },
        reader:{
            type:'json',
			totalProperty: 'totalCount',
			rootProperty: 'nodes'
        }
    }
});
