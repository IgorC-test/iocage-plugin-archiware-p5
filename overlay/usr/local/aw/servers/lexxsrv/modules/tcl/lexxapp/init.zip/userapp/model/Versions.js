Ext.define('P5U.model.Versions', {
	extend: 'Ext.data.Model',
	fields: [
		{name: 'elementurl',  type: 'string', defaultValue: '' },
		{name: 'addr',  type: 'string', defaultValue: '' },
		{name: 'parenturl',  type: 'string', defaultValue: '' },
		{name: 'instance',  type: 'string', defaultValue: '' },
		{name: 'name',  type: 'string', defaultValue: '' },
		{name: 'btime', type: 'date', dateFormat: 'U', defaultValue: '' },
		{name: 'mtime', type: 'date', dateFormat: 'U', defaultValue: '' },
		{name: 'size',  type: 'string', defaultValue: '' },
		{name: 'volume', type: 'string', defaultValue: '' },
		{name: 'location',  type: 'string', defaultValue: '' },
		{name: 'snapshot',  type: 'string', defaultValue: '' }
	]
});
