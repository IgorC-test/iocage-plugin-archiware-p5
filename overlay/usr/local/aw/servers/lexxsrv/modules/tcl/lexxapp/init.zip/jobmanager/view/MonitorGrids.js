Ext.define("OverridePluginRowExpander", {
    alias: "plugin.overriderowexpander",
    extend: "Ext.grid.plugin.RowExpander",
    addExpander: function(expanderGrid) {
        var me = this,
            expanderHeader = me.getHeaderConfig();

        // If this is the locked side of a lockable grid which is shrinkwrapping the locked width, increment its width.
        if (expanderGrid.isLocked && expanderGrid.ownerLockable.shrinkWrapLocked) {
            expanderGrid.width += expanderHeader.width;
            me.grid = expanderGrid;
        }

        // add expander column at the end of the others
        // me.expanderColumn = expanderGrid.headerCt.insert(-1, expanderHeader);

        // If a CheckboxModel, it must now put its checkbox in at position one because this
        // cell always gets in at position zero, and spans 2 columns.
        expanderGrid.getSelectionModel().injectCheckbox = 1;
        
    },
    isCollapsed: function(rowIdx) {
        var me = this,
            rowNode = me.view.getNode(rowIdx),
            row = Ext.fly(rowNode, '_rowExpander');

        return row.hasCls(me.rowCollapsedCls)
    },
    collapse: function(rowIdx) {
        if (this.isCollapsed(rowIdx) == false) {
            this.toggleRow(rowIdx, this.grid.getStore().getAt(rowIdx));
        }
    },
    collapseAll: function() {
        for (i = 0; i < this.grid.getStore().getTotalCount(); i++) {
            this.collapse(i);
        }
    },
    expand: function(rowIdx) {
        if (this.isCollapsed(rowIdx) == true) {
            this.toggleRow(rowIdx, this.grid.getStore().getAt(rowIdx));
        }
    },
    expandAll: function() {
        for (i = 0; i < this.grid.getStore().getTotalCount(); i++) {
            this.expand(i);
        }
    }
});

Ext.define("P5Jobmanager.view.MonitorGrids", {
    extend: 'Ext.panel.Panel',
    alias: "widget.monitorgrids",
    
    layout: {
        type: 'hbox',
        pack: 'start',
        align: 'stretch'
    },
    
    border: false,
    
    items: [{
        title: $$('All Running Jobs'),
        xtype: 'anymonitorgrid',
        flex: 1,
        bind: { hidden: '{!anyJobMonitor_ref.checked}' }
    },{
        title: $$('Backup & Archive Jobs'),
        xtype: 'backupmonitorgrid',
        flex: 1,
        bind: { hidden: '{isBackupJobMonitor}' }
    },{
        title: $$('Restore Jobs'),
        xtype: 'restoremonitorgrid',
        flex: 1,
        bind: { hidden: '{isRestoreJobMonitor}' }
    },{
        title: $$('Synchronize Jobs'),
        xtype: 'syncmonitorgrid',
        flex: 1,
        bind: { hidden: '{isSyncJobMonitor}' }
    },{
        title: $$('Other Jobs'),
        xtype: 'othersmonitorgrid',
        flex: 1,
        bind: { hidden: '{isOthersJobMonitor}' }
    }]
});

Ext.define("P5Jobmanager.view.AnyMonitorGrid", {
    extend: 'Ext.grid.Panel',
    alias: "widget.anymonitorgrid",

    bind:{
        store: '{runningjobsstore}'
    },
    reference: 'monitorgrid_ref',
    itemId: 'monitorgrid_id',

    viewConfig: {
        loadMask: false,
        getRowClass: function() { 
            return 'bold-row'; 
        } 
    
    },

    border: false,

    columns: [{
        xtype: 'actioncolumn',
        menuDisabled : true,
        width: 20,
        align:'center',
        stopSelection: false,
        iconCls: 'x-fa edit-icon',
        listeners: { click: 'onContextMenu' },
    },{
        dataIndex: 'status',
        menuDisabled : true,
        align: 'center',
        text: '',
        width: 20,
        renderer: function(value,metaData,record) {
            metaData.tdCls = 'backingup-icon';
        }
    },{
        dataIndex: 'jtype',
        align: 'center',
        text: '',
        menuDisabled : true,
        width: 20,
        renderer: function(value,metaData,record) {
            switch(value) {
                case 'archivejob':
                    metaData.tdCls = 'archivejob-icon';
                    break;
                case 'backupjob':
                    metaData.tdCls = 'backupjob-icon';
                    break;
                case 'backup2gojob':
                    metaData.tdCls = 'backup2gojob-icon';
                    break;
                case 'syncjob':
                    metaData.tdCls = 'syncjob-icon';
                    break;
                case 'restorejob':
                    metaData.tdCls = 'restorejob-icon';
                    break;
                default:
                    metaData.tdCls = 'otherjob-icon';
            }
        }
    },{ text: $$('Plan Name/Operation'), dataIndex: 'title', width: 200, tdCls: 'bold-node'
    },{ text: $$('Client'), dataIndex: 'client', width: 80
    },{ text: $$('Level'), dataIndex: 'level', width: 60
    },{ 
        text: $$('Start Time'),
        dataIndex: 'start',
        width: 90,
        xtype: 'datecolumn',
        format: Ext.Date.patterns['formatTimeShort']
    },{
        text: $$('Job'),
        dataIndex: 'jobid',
        flex: 1
    }],
    features: [{
        ftype: 'rowbody',
        getAdditionalData: function (data, idx, record, orig) {
            if ( record.get('id') == P5Jobmanager.globals.jobid ) {
                var caret = "x-fa fa-caret-down";
            } else {
                var caret = "x-fa fa-caret-right";
            }
            return {
                rowBodyCls: "my-body-class",
                rowBody: '<div id="rowBodywrapper"><div id="first" class="'+caret+'"></div><div id="second">'+record.get('shownreport')+'</div></div>',
            };
        }
    }],
    listeners: {
        rowbodyclick: 'onRowbodyclick'
    }
});
Ext.define("P5Jobmanager.view.BackupMonitorGrid", {
    extend: 'Ext.grid.Panel',
    alias: "widget.backupmonitorgrid",

    bind:{
        store: '{backupjobsstore}'
    },
    reference: 'backupmonitorgrid_ref',
    itemId: 'backupmonitorgrid_id',

    viewConfig: {
        loadMask: false,
        getRowClass: function() { 
            return 'bold-row'; 
        } 
    
    },

    columns: [{
        xtype: 'actioncolumn',
        menuDisabled : true,
        width: 20,
        align:'center',
        stopSelection: false,
        iconCls: 'x-fa edit-icon',
        listeners: { click: 'onContextMenu' },
    },{
        dataIndex: 'status',
        menuDisabled : true,
        align: 'center',
        text: '',
        width: 20,
        renderer: function(value,metaData,record) {
            metaData.tdCls = 'backingup-icon';
        }
    },{
        dataIndex: 'jtype',
        align: 'center',
        text: '',
        menuDisabled : true,
        width: 20,
        renderer: function(value,metaData,record) {
            switch(value) {
                case 'archivejob':
                    metaData.tdCls = 'archivejob-icon';
                    break;
                case 'backupjob':
                    metaData.tdCls = 'backupjob-icon';
                    break;
            }
        }
    },{ text: $$('Plan Name/Operation'), dataIndex: 'title', width: 200, tdCls: 'bold-node'
    },{ text: $$('Client'), dataIndex: 'client', width: 80
    },{ text: $$('Level'), dataIndex: 'level', width: 60
    },{ 
        text: $$('Start Time'),
        dataIndex: 'start',
        width: 90,
        xtype: 'datecolumn',
        format: Ext.Date.patterns['formatTimeShort']
    },{
        text: $$('Job'),
        dataIndex: 'jobid',
        flex: 1
    }]
});
Ext.define("P5Jobmanager.view.RestoreMonitorGrid", {
    extend: 'Ext.grid.Panel',
    alias: "widget.restoremonitorgrid",

    bind:{
        store: '{restorejobsstore}'
    },
    reference: 'restoremonitorgrid_ref',
    itemId: 'restoremonitorgrid_id',

    viewConfig: {
        loadMask: false,
        getRowClass: function() { 
            return 'bold-row'; 
        } 
    
    },

    columns: [{
        xtype: 'actioncolumn',
        menuDisabled : true,
        width: 20,
        align:'center',
        stopSelection: false,
        iconCls: 'x-fa edit-icon',
        listeners: { click: 'onContextMenu' },
    },{
        dataIndex: 'status',
        menuDisabled : true,
        align: 'center',
        text: '',
        width: 20,
        renderer: function(value,metaData,record) {
            metaData.tdCls = 'backingup-icon';
        }
    },{
        dataIndex: 'jtype',
        align: 'center',
        text: '',
        menuDisabled : true,
        width: 20,
        renderer: function(value,metaData,record) {
            metaData.tdCls = 'restorejob-icon';
        }
    },{ text: $$('Plan Name/Operation'), dataIndex: 'title', width: 200, tdCls: 'bold-node'
    },{ text: $$('Client'), dataIndex: 'client', width: 80
    },{ text: $$('Level'), dataIndex: 'level', width: 60
    },{ 
        text: $$('Start Time'),
        dataIndex: 'start',
        width: 90,
        xtype: 'datecolumn',
        format: Ext.Date.patterns['formatTimeShort']
    },{
        text: $$('Job'),
        dataIndex: 'jobid',
        flex: 1
    }]
});
Ext.define("P5Jobmanager.view.SyncMonitorGrid", {
    extend: 'Ext.grid.Panel',
    alias: "widget.syncmonitorgrid",

    bind:{
        store: '{syncjobsstore}'
    },
    reference: 'syncmonitorgrid_ref',
    itemId: 'syncmonitorgrid_id',

   viewConfig: {
        loadMask: false,
        getRowClass: function() { 
            return 'bold-row'; 
        } 
    
    },

    columns: [{
        xtype: 'actioncolumn',
        menuDisabled : true,
        width: 20,
        align:'center',
        stopSelection: false,
        iconCls: 'x-fa edit-icon',
        listeners: { click: 'onContextMenu' },
    },{
        dataIndex: 'status',
        menuDisabled : true,
        align: 'center',
        text: '',
        width: 20,
        renderer: function(value,metaData,record) {
            metaData.tdCls = 'backingup-icon';
        }
    },{
        dataIndex: 'jtype',
        align: 'center',
        text: '',
        menuDisabled : true,
        width: 20,
        renderer: function(value,metaData,record) {
            metaData.tdCls = 'syncjob-icon';
        }
    },{ text: $$('Plan Name/Operation'), dataIndex: 'title', width: 200, tdCls: 'bold-node'
    },{ text: $$('Client'), dataIndex: 'client', width: 80
    },{ text: $$('Level'), dataIndex: 'level', width: 60
    },{ 
        text: $$('Start Time'),
        dataIndex: 'start',
        width: 90,
        xtype: 'datecolumn',
        format: Ext.Date.patterns['formatTimeShort']
    },{
        text: $$('Job'),
        dataIndex: 'jobid',
        flex: 1
    }]
});
Ext.define("P5Jobmanager.view.OthersMonitorGrid", {
    extend: 'Ext.grid.Panel',
    alias: "widget.othersmonitorgrid",

    bind:{
        store: '{othersjobsstore}'
    },
    reference: 'othersmonitorgrid_ref',
    itemId: 'othersmonitorgrid_id',

   viewConfig: {
        loadMask: false,
        getRowClass: function() { 
            return 'bold-row'; 
        } 
    
    },

    columns: [{
        xtype: 'actioncolumn',
        menuDisabled : true,
        width: 20,
        align:'center',
        stopSelection: false,
        iconCls: 'x-fa edit-icon',
        listeners: { click: 'onContextMenu' },
    },{
        dataIndex: 'status',
        menuDisabled : true,
        align: 'center',
        text: '',
        width: 20,
        renderer: function(value,metaData,record) {
            metaData.tdCls = 'backingup-icon';
        }
    },{
        dataIndex: 'jtype',
        align: 'center',
        text: '',
        menuDisabled : true,
        width: 20,
        renderer: function(value,metaData,record) {
            metaData.tdCls = 'otherjob-icon';
        }
    },{ text: $$('Plan Name/Operation'), dataIndex: 'title', width: 200, tdCls: 'bold-node'
    },{ text: $$('Client'), dataIndex: 'client', width: 80
    },{ text: $$('Level'), dataIndex: 'level', width: 60
    },{ 
        text: $$('Start Time'),
        dataIndex: 'start',
        width: 90,
        xtype: 'datecolumn',
        format: Ext.Date.patterns['formatTimeShort']
    },{
        text: $$('Job'),
        dataIndex: 'jobid',
        flex: 1
    }]
});
