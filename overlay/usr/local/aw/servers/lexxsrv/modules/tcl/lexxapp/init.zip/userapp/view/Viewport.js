Ext.define('P5U.view.Viewport', {
    extend: 'Ext.container.Viewport',

    layout: 'border',
	cls: 'bg2',

    initComponent: function() {
        var me = this;
        this.callParent();
        me.on({
            afterrender: function() {
            	console.log('Viewport Ready');
            }
        });
    },
    items: [{
        region: 'north',
        height: 10,
        border: false,
        bodyStyle : 'background:none'
    }, {
        region: 'west',
        width: 10,
        border: false,
        bodyStyle : 'background:none'
    }, {
        region: 'south',
        height: 10,
        border: false,
        bodyStyle : 'background:none'
    }, {
        region: 'east',
        width: 10,
        border: false,
        bodyStyle : 'background:none'
    }, {
        region: 'center',
        itemId: 'CenterRegion',
        border: false,
        bodyStyle : 'background:none'
    }]
});