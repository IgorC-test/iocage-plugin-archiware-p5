//#############################################################################

//LTFSOperation.js

//JavaScript Client Library

//See the file "license.txt" for information on usage and
//redistribution of this file, and for a DISCLAIMER OF ALL WARRANTIES.


//#############################################################################

Ext.define("P5Admin.view.LTFSOperation", {
    extend: 'Ext.panel.Panel',
    alias: "widget.ltfsoperation",

    layout: {
        type: 'vbox',
        pack: 'start'
    },
        
    border: false,
    defaults: {
        margin: '10 0 0 30',
        cls: 'btn-medium-button',
        scale: 'medium',
        width: 150
    },
    items: [{
        xtype: 'button',
        handler:'onReadStart',
        text: $$('Read ...'),
        margin: '150 0 0 30',
        bind: { disabled: '{enableReadWriteButton}' }
    },{
        xtype: 'button',
        handler:'onWriteStart',
        text: $$('Write ...'),
        bind: { disabled: '{enableReadWriteButton}' }
    },{
        xtype: 'segmentedbutton',
        cls: 'btn-small-button',
        margin: '30 0 0 30',
        allowToggle: false,
        items: [{
            text: $$('Mount'),
            handler:'onMountStart',
            bind: { disabled: '{enableMountButton}' }
        }, {
            text: $$('Unmount'),
            handler:'onUnmountStart',
            bind: { disabled: '{enableUnmountButton}' }
        }]
    },{
        xtype: 'segmentedbutton',
        cls: 'btn-small-button',
        margin: '15 0 0 30',
        allowToggle: false,
        items: [{
            text: $$('Label'),
            handler:'onLabelDialog',
            bind: { disabled: '{enableLabelButton}' }
        }, {
            text: $$('Check'),
            handler:'onRepairStart',
            bind: { disabled: '{enableCheckButton}' }
        }]
    /*},{
        xtype: 'segmentedbutton',
        cls: 'btn-small-button',
        margin: '15 0 0 30',
        allowToggle: false,
        items: [{
            text: 'Move Media',
            handler:'onMoveStart',
            bind: { disabled: '{enableMoveButton}' }
        }]*/
    }]
});
