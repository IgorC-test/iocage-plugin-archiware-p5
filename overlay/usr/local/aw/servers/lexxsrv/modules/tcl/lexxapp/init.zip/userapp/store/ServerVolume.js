Ext.define('P5U.store.ServerVolume', {
	extend: 'Ext.data.TreeStore',
    model: 'P5U.model.ServerVolume',
    autoLoad: false,
    
    proxy: {
		type: 'ajax',
		url: P5U.globals.serverpage,
		timeout: 10000,
		actionMethods: 'POST',
		extraParams: {
			caller: 'ajaxGetServerVolume',
			hostname: 'localhost'
		},
        reader: {
			type: 'json'
        },
		afterRequest: function(req, res) {
			if (req.getOperation().success) {
				var panel_tree = Ext.getCmp('servervolumegrid_id');
				panel_tree.getSelectionModel().select(1);
				panel_tree.fireEvent('itemclick', panel_tree, panel_tree.getSelectionModel().getLastSelected());
			}
		}
    }
});