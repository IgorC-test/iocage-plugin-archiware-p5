Ext.define('P5U.store.IndexContent', {
	extend: 'Ext.data.TreeStore',
    model: 'P5U.model.IndexContent',
    autoLoad: false,
    
    proxy: {
		type: 'ajax',
		url: P5U.globals.serverpage,
		timeout: 10000,
		actionMethods: 'POST',
		extraParams: {
			caller: 'ajaxGetIndexContent',
			snapshot: ''
		},
        reader: {
			type: 'xml',
			rootProperty: 'nodes',
			record: 'node'
        },
		afterRequest: testResponse
    },
	listeners: {
		load: function(records, successful, eOpts ) {
			console.log('TreeStore loaded');			
		}
	},
	sorters: [{
		property: 'leaf',
		direction: 'ASC'
	},{
		property: 'name',
		direction: 'ASC'
	}]
});