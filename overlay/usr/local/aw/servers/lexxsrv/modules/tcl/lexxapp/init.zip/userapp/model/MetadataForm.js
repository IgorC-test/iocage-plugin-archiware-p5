Ext.define('P5U.model.MetadataForm', {
    extend: 'Ext.data.Model',
	fields: ['id', 'text', 'type', 'ftype', 'itype', 'ilist', 'irows']
});