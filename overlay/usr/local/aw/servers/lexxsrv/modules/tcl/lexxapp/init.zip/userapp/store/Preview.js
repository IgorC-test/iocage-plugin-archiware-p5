Ext.define('P5U.store.Preview', {
    extend: 'Ext.data.Store',
    model: 'P5U.model.Preview',
    autoLoad: false,

	proxy: {
		type: 'ajax',
		url: P5U.globals.serverpage,
		actionMethods: 'POST',
		extraParams: {
			caller: 'ajaxPreview',
			node: P5U.globals.assetUrl
		},
		reader: {
			type: 'xml',
			rootProperty: 'preview',
			record: 'image'
        },
		afterRequest: testResponse
	}
});
