Ext.define('P5U.model.ServerVolume', {
	extend: 'Ext.data.Model',
	fields: [
		{name: 'name',     type: 'string'},
		{name: 'path',     type: 'string'},
		{name: 'elementurl',     type: 'string'},
		{name: 'duration', type: 'string'}
	]
});
