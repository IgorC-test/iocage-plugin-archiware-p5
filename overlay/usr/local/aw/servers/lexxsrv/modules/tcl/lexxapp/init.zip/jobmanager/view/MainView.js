Ext.define('P5Jobmanager.view.MainView', {
    extend: 'Ext.container.Viewport',
    alias: 'widget.mainview',

    requires: [
        'P5Jobmanager.view.MainViewViewModel',
        'P5Jobmanager.view.MainViewViewController',
        'P5Jobmanager.view.JobmonitorGrids',
        'P5Jobmanager.view.UserqueuesGrids',
        'P5Jobmanager.view.JoblogGrids',
        'P5Jobmanager.view.ConfigRegion'
    ],

    controller: "mainview",

    viewModel: {
        type: 'mainview'
    },
    
    layout: 'border',
    items: [{
        xtype: 'configregion',
        region: 'west',
        split: true,
        width: 200,
        collapsed: false,
        collapsible: true,
        title: $$('Display Filters')
    },{
        xtype: 'panel',
        region: 'center',
        itemId: 'mainRegion',
        layout: 'border',
        border: false,
        items: [{
            xtype: 'userqueuesgrids',
            region: 'north',
            title: $$('Queued Jobs'),
            headerPosition: 'left',
            flex: 1,
            border: false,
            split: true
        },{
            xtype: 'jobmonitorgrids',
            region: 'center',
            title: $$('Running Jobs'),
            headerPosition: 'left',
            flex: 1,
            border: false,
            split: true
        },{
            xtype: 'jobloggrids',
            region: 'south',
            title: $$('Finished Jobs'),
            headerPosition: 'left',
            flex: 1,
            border: false,
            split: true
        }]
    }]
});