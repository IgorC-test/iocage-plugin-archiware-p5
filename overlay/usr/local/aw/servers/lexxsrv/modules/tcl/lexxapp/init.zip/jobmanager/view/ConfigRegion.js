Ext.define('Ext.override.form.field.CheckBox',{
    override : 'Ext.form.field.Checkbox',
    stateEvents : ['change'],

    getState: function () {
        var state = this.callParent(arguments) || {};
        if(this.getValue()) state = this.addPropertyToState(state, 'checked');

        return state;
    },
    applyState: function (state) {

        this.callParent(arguments);

        Ext.apply(this, state);
        if (this.checked) this.setValue(true);
    }
});

Ext.define('P5Jobmanager.view.ConfigRegion', {
    extend: 'Ext.form.Panel',

    xtype: 'configregion',

    reference: 'eventquery_form',

    bodyStyle: 'padding: 12px 0px 0px 15px;',

    border: false,

    items: [{
        xtype: 'container',
        html: $$('Manage Job Queues'),
        margin: '0 0 2 0'
    },{
        xtype: 'checkboxgroup',
        columns: 1,
        items: [
            {boxLabel: $$('Time Queue'), reference: 'scheduledUserqueues_ref', stateful : true, stateId: 'scheduledUserqueues_stateId' },
            {boxLabel: $$('User Queue(s)'), reference: 'userqueue_chkbx_ref', bind: { hidden: '{!hasOrderedJobsQueueRecords}' }, stateful : true, stateId: 'userqueue_stateId' }
        ]
    },{
        xtype: 'container',
        html: $$('Show Jobs'),
        margin: '20 0 2 0'
    },{
        xtype: 'checkboxgroup',
        columns: 1,
        items: [
            {boxLabel: $$('Any'), inputValue: 'any', reference: 'anyJobMonitor_ref', stateful : true, stateId: 'anyJobMonitor_stateId' },
            {boxLabel: $$('Archive'), inputValue: 'archive', reference: 'archiveJobMonitor_ref', bind: { disabled: '{isAnyJobMonitor}' }, stateful : true, stateId: 'archiveJobMonitor_stateId'},
            {boxLabel: $$('Backup'), inputValue: 'backup', reference: 'backupJobMonitor_ref', bind: { disabled: '{isAnyJobMonitor}' }, stateful : true, stateId: 'backupJobMonitor_stateId'},
            {boxLabel: $$('Restore'), inputValue: 'restore', reference: 'restoreJobMonitor_ref', bind: { disabled: '{isAnyJobMonitor}' }, stateful : true, stateId: 'restoreJobMonitor_stateId'},
            {boxLabel: $$('Synchronize'), inputValue: 'synchronize', reference: 'syncJobMonitor_ref', bind: { disabled: '{isAnyJobMonitor}' }, stateful : true, stateId: 'syncJobMonitor_stateId'},
            {boxLabel: $$('Others'), inputValue: 'others', reference: 'othersJobMonitor_ref', bind: { disabled: '{isAnyJobMonitor}' }, stateful : true, stateId: 'otersJobMonitor_stateId'}
        ]
    },{
        xtype: 'container',
        html: $$('Job Log'),
        margin: '20 0 2 0'
    },{
        xtype: 'checkboxgroup',
        columns: 1,
        items: [
            {boxLabel: $$('Recently Finished Jobs'), inputValue: 'finished', reference: 'finishedJobs_ref', stateful : true, stateId: 'finishedJobs_stateId' }
        ]
    },{
        xtype: 'container',
        html: $$('Server Information'),
        margin: '20 0 2 0'
    },{
        xtype: 'displayfield',
        margin: '0 0 0 3',
        bind: {
            value: '<span class="x-fa fa-clock-o" style="padding-right:3px;"> {servertime}</span>'
        },
        listeners: {
            afterrender: function(component) {
                component.getEl().on('click', 'startStopReload');  
            }
        }
    }]
});