Ext.define('P5Jobmanager.view.MainViewViewController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.mainview',
    init: function() {
 		var me = this;
        me.control({
            '#userqueuesgrids_id': {
                render: function(a,b,c) {
                    console.log('userqueuesgrids_id ready');
                    var viewModel = me.getViewModel();
                    viewModel.getStore('userqueuesstore').load();
                }
            },
            '#jobmonitorgrids_id': {
                render: function(a,b,c) {
                    console.log('jobmonitorgrids_id ready');
                    var viewModel = me.getViewModel();
                    viewModel.getStore('jobmonitorstore').load();
                    viewModel.bind('{isAjobMonitorChecked}', function(allUnChecked) {
                        if ( allUnChecked ) me.lookupReference('anyJobMonitor_ref').setValue(true);
                    });
                }
            },
            '#jobloggrid_id': {
                viewready: function(a,b,c) {
                    console.log('jobloggrid_id ready');
                    var viewModel = me.getViewModel();
                    viewModel.getStore('joblogstore').load();
                }
            }
        });    
    },
    onUserqueueStoreLoad: function( store, records, successful, eOpts ) {
        var me = this;
        console.log('onUserqueueStoreLoad');
        var panel = Ext.ComponentQuery.query('#userqueuesgrids_id')[0];
        var timeQueueGrid = Ext.create('P5Jobmanager.view.ScheduledJobQueueGrid', {
            bind: { hidden: '{!scheduledUserqueues_ref.checked}' }
        });
        panel.add(timeQueueGrid);
        var viewModel = me.getViewModel();

		store.each(function(rec){
		    var ident  = rec.get('ident');
		    var coltxt = rec.get('text');
            var referer  = ident + '_ref';
            var itemid   = ident + '_id';

            var chainedstore = new Ext.data.ChainedStore({
                source: viewModel.getStore('jobmonitorstore'),
                storeId: 'store' + ident,
                filters: [{
                    property: 'status', value: 'scheduled'
                },{
                    property: 'queue', value: ident
                }],
                sorters: [{
                    property: 'order',
                    direction: 'ASC'
                }]
            });

            var orderedQueueGrid = Ext.create('P5Jobmanager.view.OrderedJobQueueGrid', {
                reference: referer,
                itemId: itemid,
                bind: { hidden: '{!userqueue_chkbx_ref.checked}' },
                columns: [
                    { text: coltxt, dataIndex: 'text', menuDisabled : true, flex: 1 },
                    { text: $$('Order'), dataIndex: 'order', menuDisabled : true, width: 38 }
                ]
            });
            //orderedQueueGrid.setStore(chainedstore);
            orderedQueueGrid.bindStore(chainedstore);    
            panel.add(orderedQueueGrid);

        });

    },    
    onJobmonitorStoreLoad: function( store, records, successful, eOpts ) {
 		var me = this;
        //console.log('Job monitor store loaded');
        var viewModel = me.getViewModel();
        var json  = Ext.decode(eOpts.getResponse().responseText);
        var msec  = new Date(json.clocksec*1000);
        var clocl = Ext.Date.format(msec, Ext.Date.patterns['ISO8601Long']);
        viewModel.set("servertime",clocl);
        if ( successful ) me.startStopJobmonitorstoreReload(5000);
    },    
    startStopJobmonitorstoreReload: function(interval) {
        me = this;
        clearTimeout(P5Jobmanager.globals.jobmonitorstoreLoop);
        P5Jobmanager.globals.jobmonitorstoreLoop = null;
        //console.log('Starting frequently update for job monitor store');
        P5Jobmanager.globals.jobmonitorstoreLoop = setTimeout(function(){
            var upd_store = me.getView().getViewModel().getStore('jobmonitorstore');
            //if (!P5Jobmanager.globals.attention) upd_store.reload();
        },interval);
    },
    onJoblogStoreLoad: function( store, records, successful, eOpts ) {
 		var me = this;
        //console.log('Job log store loaded');
        if ( successful ) me.startStopJoblogstoreReload(5000);
    },    
    startStopJoblogstoreReload: function(interval) {
        me = this;
        clearTimeout(P5Jobmanager.globals.joblogstoreLoop);
        P5Jobmanager.globals.joblogstoreLoop = null;
        //console.log('Starting frequently update for job log store');
        P5Jobmanager.globals.joblogstoreLoop = setTimeout(function(){
            var upd_store = me.getView().getViewModel().getStore('joblogstore');
            //if (!P5Jobmanager.globals.attention) upd_store.reload();
        },interval);
    },
    startStopReload: function( event, interval ) {
        if (event && event.altKey) {
            console.log('Stop polling');
            clearTimeout(P5Jobmanager.globals.jobmonitorstoreLoop);
            clearTimeout(P5Jobmanager.globals.joblogstoreLoop);
        } else {
            console.log('Starting frequently update');
            me.startStopJobmonitorstoreReload(interval);
            me.startStopJoblogstoreReload(interval);
        }
    },    
    onMonitorgridReload: function(grid, tool, event) {
        me = this;
        console.log('onMonitorgridReload');
        var mgrid = Ext.ComponentQuery.query('#anyjobmonitorgrid_id')[0];
        var store = mgrid.getStore();
        store.reload();
    },
    onContextMenuQueued: function(view, rowIndex, collIndex, item, theEvent, record, htmlRow) {
        me = this;
        var menu = view.myMenu;
        if (!menu) {
            menu = view.myMenu = Ext.widget('menu', {
                controller: 'mainview',
                items: [{
                    iconCls: 'x-fa fa-refresh signgreen',
                    text: $$('Start now'),
                    handler: function(btn) {
                        me.onStartNow(view);
                    }
                },{
                    iconCls: 'x-fa fa-ban signred',
                    text: $$('Stop/Cancel'),
                    handler: function(btn) {
                        me.onCancelNow(view);
                    }
                }]
            });
        }
        menu.showAt(theEvent.getXY());
    },
    onContextMenuRunning: function(view, rowIndex, collIndex, item, theEvent, record, htmlRow) {
        me = this;
        var menu = view.myMenu;
        if (!menu) {
            menu = view.myMenu = Ext.widget('menu', {
                controller: 'mainview',
                items: [{
                    iconCls: 'x-fa fa-ban signred',
                    text: $$('Stop/Cancel'),
                    handler: function(btn) {
                        me.onCancelNow(view);
                    }
                }]
            });
        }
        menu.showAt(theEvent.getXY());
    },
    onStartNow: function(view) {
        console.log('onStartNow');
        var selectedRecord = view.getSelectionModel().getSelection()[0];
        var myid = selectedRecord.get('id');
        var job  = selectedRecord.get('jobid');
        Ext.Msg.show({
            title: $$('Confirm Job Start'),
            width: 360,
            message: $$('Do you really want to start this job now?'),
            buttons: Ext.Msg.YESNO,
            buttonText:{ 
                yes: $$('Start now'), 
                no: $$('No') 
            },
            icon: Ext.Msg.QUESTION,
            fn: function(btn) {
                if (btn === 'yes' ) {
                    Ext.Ajax.request({
                        waitMsg: $$('Starting job ...'),
                        url: P5Jobmanager.globals.serverpage,
                        method: 'GET',
                        params: {
                            tdp: 'orderedqueues',
                            caller: 'ajaxStartJob',
                            myid: myid,
                            job: job
                        },
                        success: function(result, request) {
                            var json = Ext.decode(result.responseText);
                            extAlert(json.attention,json.message);
                            me.startStopReload(0,1000);
                        },
                        failure: function(result, request) {
                            Ext.MessageBox.alert('Failed', result.responseText);
                        }
                    });
                }
            }
        });
    },
    onCancelNow: function(view) {
        me = this;
        console.log('onCancelNow');
        var selectedRecord = view.getSelectionModel().getSelection()[0];
        var myid = selectedRecord.get('id');
        var job  = selectedRecord.get('jobid');
        Ext.Msg.show({
            title: $$('Confirm Job Cancellation'),
            width: 360,
            message: $$('Do you really want to stop/cancel this job?'),
            buttons: Ext.Msg.YESNO,
            buttonText:{ 
                yes: $$('Stop/Cancel'), 
                no: $$('No') 
            },
            icon: Ext.Msg.QUESTION,
            fn: function(btn) {
                if (btn === 'yes' ) {
                    Ext.Ajax.request({
                        waitMsg: $$('Canceling job ...'),
                        url: P5Jobmanager.globals.serverpage,
                        method: 'GET',
                        params: {
                            tdp: 'orderedqueues',
                            caller: 'ajaxCancelJob',
                            myid: myid,
                            job: job
                        },
                        success: function(result, request) {
                            var json = Ext.decode(result.responseText);
                            extAlert(json.attention,json.message);
                            me.startStopReload(0,1000);
                        },
                        failure: function(result, request) {
                            Ext.MessageBox.alert('Failed', result.responseText);
                        }
                    });
                }
            }
        });
    },
    onRowbodyclick: function(view, rowEl, e, eOpts) {
        var me = this;
        console.log('onRowbodyclick');
        var viewModel = me.getViewModel();
        var job_store = viewModel.getStore('jobmonitorstore');
        var itemEl = Ext.get(rowEl).up(view.itemSelector);
        var record = view.getRecord(itemEl);
        var jobid  = record.get('id');

        // incase jobid is the same close the long report
        // if ( jobid == P5Jobmanager.globals.jobid ) jobid = null;
        // P5Jobmanager.globals.jobid = jobid;

        var idx = P5Jobmanager.globals.jobid.indexOf(jobid);
        if ( idx > -1 ) {
            P5Jobmanager.globals.jobid.splice(idx, 1);
        } else {
            P5Jobmanager.globals.jobid.push(jobid);
        }
        job_store.reload();
    }    
});
