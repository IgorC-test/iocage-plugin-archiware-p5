Ext.define('P5U.store.MetadataForm', {
    extend: 'Ext.data.Store',
    model: 'P5U.model.MetadataForm',
    autoLoad: false,
    
    proxy: {
		type: 'ajax',
		url: P5U.globals.serverpage,
		actionMethods: 'POST',
		extraParams: {
			caller: 'ajaxMetaForm',
			node: P5U.globals.nodeUrl
		},
        reader: {
			type: 'xml',
			record: 'metafield'
        },
		afterRequest: testResponse
    }
});