Ext.define('P5U.model.IndexContent', {
	extend: 'Ext.data.Model',
		fields: [
			{name: 'id',  type: 'string', defaultValue: ''},
			{name: 'name', type: 'string', defaultValue: '' },
			{name: 'path', type: 'string', defaultValue: '' },
			{name: 'checked', type: 'boolean', defaultValue: false }
		]
});