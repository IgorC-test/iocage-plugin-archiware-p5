Ext.define("P5idx.model.IdxFolderContent", {
    extend: "Ext.data.TreeModel",
    idProperty: "id",
    schema: {
        namespace: "P5idx.model"
    },

    fields: [{
        name: 'id',
        type: 'string'
    },{
        name: 'path',
        type: 'string'
    },{
        name: 'name',
        type: 'string'
    }],
    proxy:{
        type:'ajax',
        url:P5idx.globals.serverpage,
        actionMethods:{
             read:'GET'
        },
        extraParams: {
            caller: 'ajaxGetFolderContent'
        },
        reader:{
            type:'json',
			totalProperty: 'totalCount',
			rootProperty: 'nodes'
        },
		afterRequest: testResponse        
    }
});
